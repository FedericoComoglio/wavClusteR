#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#2013 - Federico Comoglio & Cem Sievers, D-BSSE, ETH Zurich
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

annotateClusters <- function( clusters, txDB = NULL, genome = 'hg19', tablename = 'ensGene', plot = TRUE, verbose = TRUE ) {
# Annotates clusters w.r.t. genomic annotations from UCSC
#
# Args:
#   clusters: GRanges object containing individual clusters as identified by getClusters
#   txDB: TranscriptDb object obtained through the makeTranscriptDbFromUCSC function. Default is NULL, namely the object will be fetched internally
#   genome: character, genome abbreviation used by UCSC and obtained by ucscGenomes()[ , "db"]. Default is human genome (hg19)
#   tablename: character, name of the UCSC table containing the transcript annotations to retrieve, according to supportedUCSCtables(). Default is ensembl gene annotation (ensGene)
#   plot: logical, if TRUE plots dotchart
#   verbose: logical, if TRUE, prints steps. Default is true
#
# Returns:
#   GRanges object witwh clusters, with an additional elementMetadata column containing a character identifier of the genomic feature each cluster maps to. If plot, then a dotchart is returned in addition.
#
# Error handling
#   if txDB not provided, check that genome and tablename are within those available from UCSC, otherwise raise an error
	
	availGenomes <- ucscGenomes()[ , 'db']
	availTables <- rownames( supportedUCSCtables() )
	if( is.null( txDB ) & (!(genome %in% availGenomes) | (!(tablename %in% availTables))) ) {
		stop('transcriptDB object not provided and genome or tablename not within 
		      those available from UCSC. Please use ucscGenomes()[ , \'db\'] and supportedUCSCtables() 
                      for a list of supported ones.')
	}

	#1-if not provided, create the TranscriptDb object
	if( is.null( txDB ) ) {
		if(verbose)
			message( 'Creating TranscriptDb object...' )
		txDB <- makeTranscriptDbFromUCSC(genome = genome, tablename = tablename)
	}
	
	#2-obtaining CDS, introns, 3' and 5'-UTRs from the TranscriptDb object
	if(verbose)
		message( 'Extracting genomic features from TranscriptDb object...' )

	cds <- cdsBy( txDB )
	ix <- intronsByTranscript( txDB )
	tpUTR <- threeUTRsByTranscript( txDB )
	fpUTR <- fiveUTRsByTranscript( txDB )

	#3-find overlaps on the sense strand, return a matrix
	if(verbose)
		message( 'Computing overlaps with genomic features on the sense strand...' )
	
	Olaps <- cbind( olaps.cds   = countOverlaps( clusters, cds ),
      		        olaps.ix    = countOverlaps( clusters, ix ),
      		        olaps.tpUTR = countOverlaps( clusters, tpUTR ),
     		        olaps.fpUTR = countOverlaps( clusters, fpUTR) )
	
	Olaps <- Olaps > 0 #transform to logical
	rs <- rowSums( Olaps )
	not.mapped.idx <- which( rs == 0 ) #vector of cluster indices for which no mapping was found	

	#4-prepare output
	n <- length( clusters )  
	emd.anno <- rep( '', n ) #future elementMetadata containing annotation label for each cluster

	#5-flag ambigous/multiple mappings
	multiple <- which( rs > 1 ) #logical comparison, 1 if ambigous
	emd.anno[ multiple ] <- 'Multiple'
	Olaps[ multiple, ] <- FALSE  #multiple mappings are cleared

	category.idx <- apply( Olaps, 2, which, TRUE ) #list of indices of clusters mapping to same feature
	emd.anno[ category.idx$olaps.cds ] <- 'CDS ss'
	emd.anno[ category.idx$olaps.ix ] <- 'Introns ss'
	emd.anno[ category.idx$olaps.tpUTR ] <- '3\' UTR ss'
	emd.anno[ category.idx$olaps.fpUTR ] <- '5\' UTR ss'
		
	#5-count overlaps by feature
	summ <- colSums( Olaps )
	n.multiple <- length( multiple )
	summ <- c( summ, n.multiple, n - sum( summ ) - n.multiple )	#n-sum(summ): not mapped
	
	#6-consider not-mapped ones and map them w.r.t antisense strand
	if(verbose)
		message( 'Considering non-mapped clusters and computing overlaps with genomic features on the antisense strand...' )

	not.mapped <- clusters[ not.mapped.idx ]
	plus <- strand( not.mapped ) == '+'
	minus <- strand( not.mapped ) == '-'
	strand( not.mapped[ plus ] ) <- '-'	
	strand( not.mapped[ minus ] ) <- '+'

	Olaps.antisense <- cbind( olaps.cds   = countOverlaps( not.mapped, cds ),
      		        olaps.ix    = countOverlaps( not.mapped, ix ),
      		        olaps.tpUTR = countOverlaps( not.mapped, tpUTR ),
     		        olaps.fpUTR = countOverlaps( not.mapped, fpUTR) )
	
	Olaps.antisense <- Olaps.antisense > 0 #transform to logical

	multiple <- which( rowSums( Olaps.antisense ) > 1 ) #logical comparison, > 1 if ambigous
	emd.anno[ not.mapped.idx[ multiple ] ] <- 'Multiple'
	Olaps.antisense[ multiple, ] <- FALSE

	category.idx.antisense <- apply( Olaps.antisense, 2, which, TRUE ) #list of indices of clusters mapping to same feature
	emd.anno[ not.mapped.idx[ category.idx.antisense$olaps.cds ] ] <- 'CDS as'
	emd.anno[ not.mapped.idx[ category.idx.antisense$olaps.ix ] ] <- 'Introns as'
	emd.anno[ not.mapped.idx[ category.idx.antisense$olaps.tpUTR ] ] <- '3\' UTR as'
	emd.anno[ not.mapped.idx[ category.idx.antisense$olaps.fpUTR ] ] <- '5\' UTR as'
	emd.anno[ which( emd.anno == '' ) ] <- 'Other' #the remaining unmapped clusters are assigned here
	elementMetadata( clusters )[, 'MapsTo'] <- emd.anno 
	
	#7-count overlaps on the antisense strand by feature
	n.not.mapped <- length( not.mapped )
	summ.antisense <- colSums( Olaps.antisense )
	n.multiple <- length( multiple )
	summ.antisense <- c( summ.antisense, n.multiple, n.not.mapped - sum( summ.antisense ) - n.multiple )

	#8-plot the results as dotchart
	if( plot ) {
		names( summ ) <- c('CDS', 'Introns', '3\'-UTR', '5\'-UTR', 'Multiple', 'Other')
		names( summ.antisense ) <- c('CDS', 'Introns', '3\'-UTR', '5\'-UTR', 'Multiple', 'Other')
		summ <- sort( summ, decreasing = TRUE )
		summ.antisense <- sort( summ.antisense, decreasing = TRUE )	
	
		print(summ)
		print(summ.antisense)

		par(mfrow = c(1,2))
			dotchart2( summ, 
                                   main = paste( 'Sense strand (n=', sum(summ), ')', sep = '' ),
  	                           xlab = 'Number of wavClusters',
				   col = 'blue3',
                                   dotsize = 1.2 )
			grid()
			dotchart2( summ.antisense,
                                   main = paste( 'Antisense strand (n=', sum(summ.antisense), ')', sep = '' ), 
			           xlab = 'Number of wavClusters',
                                   col = 'orange',
                                   dotsize = 1.2 )
			grid()
	}

	#10-return clusters with annotation as additional column in elementMetadata
	return( clusters )
}

