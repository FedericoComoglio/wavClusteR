#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#2013 - Federico Comoglio & Cem Sievers, D-BSSE, ETH Zurich
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

plotSizeDistribution <- function( clusters, ... ) {
# Plot the size distribution of clusters
#
# Args:
#   clusters: GRanges object containing valid clusters as returned by filterClusters
#
# Returns:
#   called for its effect, returns an histogram
#
# Error handling
#   ... 
	sizeV <- width( clusters )
	hist( sizeV, ..., main = 'Size distribution', 
			  xlab = 'Length (bases)', 
			  ylab = 'Number of wavClusters' )
}
