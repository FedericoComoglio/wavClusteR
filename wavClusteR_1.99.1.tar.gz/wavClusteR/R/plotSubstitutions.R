#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#2013 - Federico Comoglio & Cem Sievers, D-BSSE, ETH Zurich
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
#~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

plotSubstitutions <- function( countTable, highlight = 'TC' ) {
# produce barplot of observed substitutions
#
# Args:
#   countTable:  a GRanges object, corresponding to a count table where each substitution has a corresponding strand-specific coverage and a count value, as returned by the getFilteredSub function
#   highlight: character, the substitution to be highlighted in the plot
#
# Returns:
#   called for its effect, returns a barplot
#
# Error handling
#   ...
	#1-extract substitutions and compute summary table
	subst <- elementMetadata( countTable )[, 'substitutions'] 
	counts <- table( subst )

	#2-remove substitutions involving Ns
	remove <- names( counts ) %in% c( 'AN', 'CN', 'GN', 'TN' )
	counts <- counts[ !remove ]
	n <- length( counts )

	#3-prepare plot and highlight transition of interest
	substNames <- names( counts )
	posHL <- which( substNames == highlight ) #position of the substitution to highlight
	percentage <- round( counts[ posHL ] / sum( counts ) * 100, 2 )
	col <- rep( 'gray60', n )
	col[ posHL ] <- 'green3'
	barplot( counts,
                 cex.names = 0.8, 
	   	 names.arg = substNames,
		 main      = paste( 'Substitutions profile, ', highlight, ' = ', percentage, ' %', sep = '' ), 
		 ylab      = 'Number of genomic positions',
		 col       = col )
}



 
	
