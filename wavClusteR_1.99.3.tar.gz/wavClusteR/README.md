wavClusteR
==========

wavClusteR is an R/BioConductor package for PAR-CLIP data analysis.

For more information, please visit http://federicocomoglio.github.io/wavClusteR